// import {mul,add} from "./calc.js"
// import "./index.css";
 
 //  const {add}=require("./index")
//  console.log(add(13,45))
//  console.log(mul(13,45))
//  const h1=document.createElement("h1")
//  h1.innerText="Welcome to webpack";
//  h1.classList.add("redt");
//  document.getElementById("root").append(h1)
document.querySelector("#myform").addEventListener("submit",additem)

 function additem(event){
     event.preventDefault();
     var name = document.querySelector("#name").value;
     var qty = document.querySelector("#qty").value;
     var Priority = document.querySelector("#Pri").value;
     console.log(name,qty,Priority)

     var row = document.createElement("tr");

     var td1 = document.createElement("td");
     td1.textContent=name
     var td2 = document.createElement("td");
     td2.textContent=qty
     var td3 = document.createElement("td");
     td3.textContent = Priority
     if( Priority === "high"){
         td3.style.backgroundColor = "red"
     }
     var td4 = document.createElement("td");
     td4.textContent = "Delete";
     td4.addEventListener("click",deletetask)


     row.append(td1, td2, td3, td4)

     document.querySelector("tbody").append(row);

 }
 function deletetask(event){
 event.target.parentNode.remove()
 }
