

//  function add(a,b)
// {
//     return a+b;
// }
// console.log(add(2,3))
// console.log(add(6,3))

// function mul(c,d)
// {
//     return c*d;
// }
// export{mul,add};
//   module.exports={add}
